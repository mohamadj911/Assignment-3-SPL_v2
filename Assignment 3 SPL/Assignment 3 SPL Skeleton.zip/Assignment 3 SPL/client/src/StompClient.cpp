int main(int argc, char *argv[]) {
	// TODO: implement the STOMP client
	return 0;
}